# Sistema de Notificação Distribuído para Estudantes e Professores

A Pen created on CodePen.io. Original URL: [https://codepen.io/Alexandre-Gomes-the-typescripter/pen/MWMBgzO](https://codepen.io/Alexandre-Gomes-the-typescripter/pen/MWMBgzO).

