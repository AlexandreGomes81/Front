//busca o ID no html e armazena a uma variavél id=forma -> const forma
const forma= document.getElementById('forma');
const email= document.getElementById('email');
const matricula= document.getElementById('matricula');

//associa eventos aos elementos do formulário
//'forma' é a variável que está armazenado todos os elementos da tela de cadastro: Email, Matricula e enviar.
//'submit' é uma váriavel exclusiva que define o evento quando o usuário envia o formulário
//'evento' armazena o objeto do evento
forma.addEventListener('submit', (evento)=>{
//impede o envio do formulário 
  evento.preventDefault(); 
  //validar os campos
  checkInputs();
        });
//função que verifica o E-mail e Matrícula
function checkInputs(){
 //recebe os valores dos campos digitados 
 const emailValue = email.value.trim();
 const matriculaValue = matricula.value.trim();
//se o valor estiver vazio...
 if(emailValue === ''){
 //condição de erro caso esteja vazio
setErrorFor(email,'E-mail está vazio');
 //se não estiver vazio caso os valores do E-mail não esteja de acordo com 'isEmail' resulta em erro
 }else if(!isEmail(emailValue)){
   setErrorFor(email, 'E-mail não válido')
  //se for válido e correto 
 }else{
   setSucessFor(email);
 }
  if(matriculaValue ===''){
  setErrorFor(matricula, 'matricula está vazia');
  }else{
    setSucessFor(matricula);
  }
  function setErrorFor(input, message){
    const ControleDeForma = input.parentElement;
    const small = ControleDeForma.querySelector('small');
    small.innerText = message;
    ControleDeForma.className = "controle-de-forma falso";
  }
 function setSucessFor(input){
   const ControleDeForma = input.parentElement
   ControleDeForma.className = "controle-de-forma verdadeiro";
    
  }
  function isEmail(email){
    return /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(email);
  }
}